# CloudEats Food Ordering Application

A cloud-native food ordering application built for learning cloud computing concepts.
